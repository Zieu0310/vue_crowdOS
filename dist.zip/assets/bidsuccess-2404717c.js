const s="/assets/bidsuccess-f758eca5.png";export{s as _};
