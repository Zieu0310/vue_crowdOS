import{f as a}from"./index-5f8c7125.js";const o=(t,r)=>a({method:"post",url:`/tender/${t}`,params:{event_id:t},data:{bid:r}});export{o as t};
