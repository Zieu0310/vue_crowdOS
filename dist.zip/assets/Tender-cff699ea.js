import{f as a}from"./index-14b13172.js";const o=(t,r)=>a({method:"post",url:`/tender/${t}`,params:{event_id:t},data:{bid:r}});export{o as t};
