const s="/assets/group-abe6df46.png";export{s as _};
