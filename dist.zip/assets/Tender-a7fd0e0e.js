import{f as a}from"./index-d8a69d2a.js";const o=(t,r)=>a({method:"post",url:`/tender/${t}`,params:{event_id:t},data:{bid:r}});export{o as t};
